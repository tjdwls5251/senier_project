import React from 'react';

import Main_Header from '../Component/Main_Header';
import Main_menu from '../Component/Main_menu';
import Main_Categories from '../Component/Main_Categroies';
import "../CSS/We'Re Cycle.css";

import 'react-bootstrap';


function MainPage() {

    const categories=[
        {title:'0'},
        {title:'1'},
        {title:'2'},
        {title:'3'},
        {title:'4'},
        {title:'5'},
      ];
    
      const readCategory = categories.map(category => {
        return(
          <Main_Categories category={category} />
          );
      });

    return (
    <div className="background text-center">
      <Main_Header />
      <Main_menu />
      <div className="container  main-border">
        <div className="row ">
          {readCategory}
        </div>
      </div>
    </div>

    )
}
export default MainPage;