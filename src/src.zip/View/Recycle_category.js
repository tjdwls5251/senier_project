import React from 'react';


function Recycle_category(){ 
    return(
        <div>
            <h1>hello</h1>
            <h1>hello</h1>
        </div>
    )
}
export default Recycle_category;
