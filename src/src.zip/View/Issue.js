import React from 'react';
import Category_Header from '../Component/Category_Header'
import Category_title from "../Component/Category_title"
import Category_search from "../Component/Category_search"
import Pagination from "../Component/Pagination"

import 숲스토리 from "../pictures/숲스토리.png"
import 리싸이클오피스 from "../pictures/리싸이클오피스.png"
import Logo from "../pictures/Logo.png"
import sample3 from "../pictures/sample3.png"
import 가구매장 from "../pictures/가구매장.png"
import map from "../pictures/map.gif"
import WeReCycle from "../pictures/We'Re Cycle.png"
import sample1 from "../pictures/sample1.png"
import sample2 from "../pictures/sample2.png"

import "../CSS/Issue.css"

function Issue(){
    const database_issue=[
        {url:'https://www.naver.com/',이미지:숲스토리,날짜:'2021.03.24',내용:'정지퀘도 환경위성 대기질 정보 8종 영상 공개!'},
        {url:'https://www.naver.com/',이미지:리싸이클오피스,날짜:'2021.03.27',내용:'물과 미래의 가치를 생각하자'},
        {url:'https://www.naver.com/',이미지:Logo,날짜:'2021.03.14',내용:'도금 . 염색 업종에 특화된 유해화학물질 취급시 위험!'},
        {url:'https://www.naver.com/',이미지:sample3,날짜:'2021.03.10',내용:'[자상한 소비 실천] 착한 소비를 지향하는 그린 자연환경'},
        {url:'https://www.naver.com/',이미지:가구매장,날짜:'2021.03.02',내용:'[환경부X 자까 작가 수돗물툰] 우리 수돗물 수질 안전한지 확인 해봐야한다, 고 한다'},
        {url:'https://www.naver.com/',이미지:map,날짜:'2021.02.28',내용:'[환경정책 알림] 2021 환경정책 투명 페트병 별로 알아서 잘분리하시길 바랍니다.'},
        {url:'https://www.naver.com/',이미지:WeReCycle,날짜:'2021.03.10',내용:'[자상한 소비 실천] 착한 소비를 지향하는 그린 자연환경'},
        {url:'https://www.naver.com/',이미지:sample1,날짜:'2021.03.02',내용:'[환경부X 자까 작가 수돗물툰] 우리 수돗물 수질 안전한지 확인 해봐야한다, 고 한다'},
        {url:'https://www.naver.com/',이미지:sample2,날짜:'2021.02.28',내용:'[환경정책 알림] 2021 환경정책 투명 페트병 별로 알아서 잘분리하시길 바랍니다.'},

    ];

    const readdatebase_issue= database_issue.map(database_issue => {
        return(
            <div className="card col-4" style={{border:"0px"}} >
                <a href={database_issue.url}>
                    <img src={database_issue.이미지} alt="Card image"/>
                    <p className="date">{database_issue.날짜}</p>
                    <p className="text">{database_issue.내용}</p>
                 </a>
            </div>
          );
      });
    return(
        <div>
            <Category_Header title='1' />
            <div className="container main-border">
                <Category_title title='1' />
                <Category_search />
                <div class="Issue container row">
                    {readdatebase_issue}
                </div>
                <div className="footer">
                <Pagination/>
                </div>

            </div>

        </div>
    )
}

export default Issue;
