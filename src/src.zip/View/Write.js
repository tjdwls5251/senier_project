import React from 'react';
import { useHistory } from 'react-router';
import Category_Header from '../Component/Category_Header'
import Category_title from "../Component/Category_title"

import "../CSS/Write.css"

function Write() {
    const history= useHistory();

    const goBack = () =>{
        history.goBack();
    };
    return(
        <div>
            <Category_Header />

            <div className="container main-border">

                <Category_title title='6' />
                <table className="Write_table table table-bordered">
                    <tbody>
                        <tr>
                            <td>제목</td>
                            <td><input className="form-control ml-1" type="text"  placeholder="제목을 작성해 주세요"/></td>
                        </tr>
                        <tr>
                            <td>내용</td>
                            <td><p><textarea placeholder="&#13;&#10; 광고 및 불건전한 질문은 강제 삭제됩니다&#13;&#10;&#13;&#10; 모든 게시글은 익명입니다&#13;&#10;&#13;&#10; 모두가 함께 사용하며 질문하는 게시판을&#13;&#10;&#13;&#10; 깨끗한 글로 채워갑시다 :)"></textarea></p></td>
                        </tr>
                        <tr>
                            <td>비밀번호</td>
                            <td><input className="form-control ml-1" type="text"  placeholder="비밀번호를 입력해주세요(본인 글 삭제시 사용)"/></td>
                        </tr> 
                    </tbody>
                 </table>
                 <div class="Write_footer">
                    <button class="btn btn-outline-danger" type="button"  onClick={goBack}>
                        <span class="fa fa-undo fa-md ">뒤로가기</span>        
                    </button>
                    <button class="btn btn-outline-success" type="button"  onClick="7location.href='Qna.html'" >
                        <span class="fa fa-pen fa-md ">글쓰기</span>        
                    </button>
                </div>
            </div>
        </div>
    )
}
export default Write;
