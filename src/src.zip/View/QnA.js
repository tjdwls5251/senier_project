import React from 'react';
import Category_Header from '../Component/Category_Header'
import Category_title from "../Component/Category_title"
import Category_search from "../Component/Category_search"
import Pagination from "../Component/Pagination"
import {Link} from "react-router-dom"

import "../CSS/QnA.css"

function QnA(){
    const database=[
        {순서:11,제목:'숫자 2자리수는 어떨까요',작성일:'2021-04-21',조회수:222},
        {순서:4,제목:'잘하고 있는거 맞을까요',작성일:'2021-04-09',조회수:2},
        {순서:3,제목:'언제쯤 끝날까요',작성일:'2021-04-08',조회수:210},
        {순서:2,제목:'그냥 적어봤음',작성일:'2021-04-04',조회수:123},
        {순서:1,제목:'5',작성일:'2021-03-26',조회수:1290},
        {순서:1,제목:'6',작성일:'2021-03-26',조회수:1290},
        {순서:1,제목:'7',작성일:'2021-03-26',조회수:1290},
        {순서:1,제목:'8',작성일:'2021-03-26',조회수:1290},
        {순서:1,제목:'9',작성일:'2021-03-26',조회수:1290},
        {순서:1,제목:'10',작성일:'2021-03-26',조회수:1290},

    ];

    const readdatebase = database.map(database => {
        return(
        <tr>
            <td>{database.순서}</td>
            <td>{database.제목}</td>
            <td>{database.작성일}</td>
            <td>{database.조회수}</td>
        </tr>
          );
      });
  return (
    <div>
        <Category_Header title='5'/>
      
      <div className="container main-border">
          
            <Category_title title='5' />
           
            <Category_search />
            
            <table className="QnA_table table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>순서</th>
                        <th>제목</th>
                        <th>작성일</th>
                        <th>조회수</th>
                    </tr>
                </thead>

                <tbody>
                  {readdatebase}
                </tbody>
            </table>
            <div className="footer">
                <Pagination/>

                <div className="write" >
                    <Link to= '/QnA/Write'>
                        <button className="btn btn-outline-success" type="button">
                            <span className="fa fa-pen fa-md ">글쓰기</span>        
                        </button>
                    </Link>
                </div>

            </div>
        </div>

  </div>
  )
}
export default QnA;

