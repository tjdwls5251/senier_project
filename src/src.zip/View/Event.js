import React from 'react';
import Category_Header from '../Component/Category_Header'
import Category_title from "../Component/Category_title"
import Category_search from "../Component/Category_search"

function Event(){
    return(
        <div>
            <Category_Header title='2' />
            <div className="container main-border">
            <Category_title title='2' />
            <Category_search />
        </div>

        </div>
    )

}
export default Event;
