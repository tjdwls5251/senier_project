import React from 'react';
import QnA from './QnA';
import Write from './Write';
import MainPage from './MainPage';
import Address from './Address';
import Store from './Store';
import Issue from './Issue';
import Recycle from './Recycle';
import Event from './Event';
import Recycle_category from './Recycle_category';
import "../CSS/public.css"
import 'react-bootstrap';


import{
  BrowserRouter as Router,
  Switch,
  Route
  
} from "react-router-dom";
function App(props) {
  
  return (

    <Router>
      <Switch>
        <Route path="/QnA/Write"  >
          <Write/>
        </Route>

        <Route path="/QnA"  >
          <QnA/>
        </Route>
   
        <Route path="/address">
          <Address/>
        </Route>

        <Route path="/store">
          <Store/>
        </Route>

        <Route path="/Issue">
          <Issue/>
        </Route>

        <Route path="/Event">
          <Event/>
        </Route>

        <Route path='/Recycle/category'>
          <Recycle_category />
        </Route>

        <Route path="/Recycle">
          <Recycle />
        </Route>

        <Route path="/">
          <MainPage/>
        </Route>
    </Switch>
  </Router>
  );
}

export default App;
