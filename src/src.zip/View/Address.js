import React from 'react';
import Category_Header from '../Component/Category_Header'
import Category_title from "../Component/Category_title"
import Category_search from "../Component/Category_search"
import Pagination from "../Component/Pagination"
import "../Component/search_address.js"
import  "../CSS/Address.css"
 
function About(){
    const database_address=[
        {지역:'동대문구 재활용 관리센터',전화번호:'02-2423-1313'},
        {지역:'중구 재활용 관리센터',전화번호:'02-2523-2314'},
        {지역:'성동구 재활용 관리센터',전화번호:'02-2631-3316'},
        {지역:'성북구 재활용 관리센터',전화번호:'02-2723-4317'},
        {지역:'서대문구 재활용 관리센터5',전화번호:'02-2823-5318'},
        {지역:'서대문구 재활용 관리센터6',전화번호:'02-2823-5318'},
        {지역:'서대문구 재활용 관리센터7',전화번호:'02-2823-5318'},
        {지역:'서대문구 재활용 관리센터8',전화번호:'02-2823-5318'},
        {지역:'서대문구 재활용 관리센터9',전화번호:'02-2823-5318'},
        {지역:'서대문구 재활용 관리센터10',전화번호:'02-2823-5318'},

    ];
    const readdatebase_address = database_address.map(database_address => {
        return(
        <tr>
            <td><i className="address_icon fa fa-map-marker-alt fa-md"></i>{database_address.지역}</td>
            <td><i className="address_icon fa fa-phone-volume fa-md"></i>{database_address.전화번호}</td>
        </tr>
          );
      });
  return (
    <div>
      <Category_Header title='4'/> 
        <div className="container main-border">
            
            <Category_title title='4' />
            <Category_search title='1'/>
            <table class="address_table table table-bordered table-striped">
                <thead>
                    <tr>
                        <th class="center_border">지역</th>
                        <th>전화번호</th>
                    </tr>
                </thead>
                <tbody>
                    {readdatebase_address}
                </tbody>
            </table>
            <div className="footer">
                    <Pagination/>
            </div>
        </div>
        <h1>
            <div>

                {/* <a href="#" onCLick={window.open('https:naver.com')}>
                    hello
                </a> */}
            </div>
        </h1>
    </div>
  );
};

export default About;