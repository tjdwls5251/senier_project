import React from 'react';
import camera from "../pictures/camera.png";
import upload from "../pictures/upload.png";
function Main_menu(){
    return(
        <div className="container main-border">
            <div className="menu">
                <div>
                  <img src={camera} style={{maxWidth:"100%", height:"auto"}}/>
                </div>
                <div>
                <img src={upload} style={{maxWidth:"100%", height:"auto"}}/>
                </div>              
            </div>
        
        </div>
            
    )
}

export default Main_menu;
