import React from 'react';
import 분리배출 from "../pictures/분리배출.png";
import 이슈 from "../pictures/이슈.png";
import 이벤트 from "../pictures/이벤트.png";
import 매장 from "../pictures/매장.png";
import 위치 from "../pictures/위치.png";
import QA from "../pictures/QA.png";
import 'react-bootstrap';
import {Link} from 'react-router-dom';
function Categories(props){
    let category = [분리배출, 이슈, 이벤트, 매장,위치,QA];
    let title = ['분리배출', '최근 이슈', '이벤트 정보', '친환경 매장','지역 위치','질문 게시판'];
    let page = ['/Recycle', '/Issue', '/Event', '/store','/address','/QnA'];
 
    return(
        
        <div className="col-lg-4 col-sm-2">
            <div className="main-page card" style={{border:"0px"}}>    
                <Link to={page[props.category.title]}>
                    <img className="card-img-top" src={category[props.category.title]} alt='이미지'/>
                </Link>                 
                <div className="d-none d-lg-block">
                    <div className="card-body ">
                    <Link to={page[props.category.title]}>
                        <button type="button" className="test btn-block btn-dark"  style={{fontSize:"2.8rem"}} > {title[props.category.title]}</button>
                    </Link>
                    </div>
                </div>
                
            </div>
      


        </div>

    )
}
export default Categories;
