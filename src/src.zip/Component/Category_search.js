import React from 'react';

function Category_search(props) {
   
    return (
        <div className="Search">
            <div className="select_date">
                <input type='date' name='start_date' />
                <h1>~</h1>
                <input type='date' name='end_date' />
            </div>
            <div className="search_input" style={{ width: "100%" }}>
                <input className="form-control" type="text" placeholder="검색어를 입력해주세요." aria-label="Search" />
            </div>
            <div>
                <button className="btn btn-outline-info" type="submit">
                    <span className="fa fa-search fa-md ">Search</span>
                </button>
            </div>
        </div>
    )
}

export default Category_search;