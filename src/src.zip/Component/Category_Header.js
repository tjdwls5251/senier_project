import React from 'react';
import Logo from "../pictures/We'Re Cycle.png";
import {Link} from 'react-router-dom';
function Category_Header(props) {
    let className=['0','1','2','3','4','5'];

    if(props.title==className[0]){
        className[0]='colorstyle';
        className[1]='blackstyle';
        className[2]='blackstyle';
        className[3]='blackstyle';
        className[4]='blackstyle';
        className[5]='blackstyle';
    }else if(props.title==className[1]){
        className[0]='blackstyle';
        className[1]='colorstyle';
        className[2]='blackstyle';
        className[3]='blackstyle';
        className[4]='blackstyle';
        className[5]='blackstyle';
    }else if(props.title==className[2]){
        className[0]='blackstyle';
        className[1]='blackstyle';
        className[2]='colorstyle';
        className[3]='blackstyle';
        className[4]='blackstyle';
        className[5]='blackstyle';
    }else if(props.title==className[3]){
        className[0]='blackstyle';
        className[1]='blackstyle';
        className[2]='blackstyle';
        className[3]='colorstyle';
        className[4]='blackstyle';
        className[5]='blackstyle';
    }else if(props.title==className[4]){
        className[0]='blackstyle';
        className[1]='blackstyle';
        className[2]='blackstyle';
        className[3]='blackstyle';
        className[4]='colorstyle';
        className[5]='blackstyle';
    }else{
        className[0]='blackstyle';
        className[1]='blackstyle';
        className[2]='blackstyle';
        className[3]='blackstyle';
        className[4]='blackstyle';
        className[5]='colorstyle';
    }
    
    return(
    <div>
        <header>
            <Link to="/">
                <img src={Logo} style={{ maxWidth: "100%", height: "auto" }} />
            </Link>
        
        </header>

        <div className="container navigation">
            <ul className="nav nav-tabs"style={{fontSize:'25px'}} >
                <li className="nav-item">
                    <Link className={className[0]} to="/Recycle" >분리배출 방법</Link>
                </li>
                <li className="nav-item">
                    <Link className={className[1]} to="/Issue">최근이슈</Link>
                </li>
                <li className="nav-item">
                    <Link className={className[2]} to="/Event" >이벤트 정보</Link>
                </li>
                <li className="nav-item">
                    <Link className={className[3]} to="/store" >친환경 매장</Link>
                </li>
                <li className="nav-item">
                    <Link className={className[4]} to="/address" >지역 정보</Link>
                </li>
                <li className="nav-item">
                    <Link className={className[5]}to="/QnA" >질문 게시판</Link>
                </li>
            </ul>
        </div>
        
  </div>

  )
}

export default Category_Header;